from project.fruit import Fruit
from project.food import Food

fruit = Fruit("banana", "2024-03-01")
print(fruit.name)